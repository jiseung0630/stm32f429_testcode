/*
 * io.h
 *
 *  Created on: Mar 29, 2024
 *      Author: iot00
 */

#ifndef SRC_IO_H_
#define SRC_IO_H_

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

int __io_putchar(int ch);

#ifdef __cplusplus
}
#endif

#endif /* SRC_IO_H_ */
