/*
 * app.h
 *
 *  Created on: Apr 8, 2024
 *      Author: iot00
 */

#ifndef INC_APP_H_
#define INC_APP_H_

#ifdef __cplusplus
extern "C" {
#endif

void app(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_APP_H_ */
