/*
 * polling.h
 *
 *  Created on: Apr 15, 2024
 *      Author: iot00
 */

#ifndef INC_POLLING_H_
#define INC_POLLING_H_


#ifdef __cplusplus
extern "C" {
#endif

void polling_init(void);

#ifdef __cplusplus
}
#endif

#endif /* INC_POLLING_H_ */
