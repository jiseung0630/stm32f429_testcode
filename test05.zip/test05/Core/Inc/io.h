/*
 * io.h
 *
 *  Created on: Apr 11, 2024
 *      Author: iot00
 */

#ifndef INC_IO_H_
#define INC_IO_H_

#include <stdbool.h>
#include "main.h"

#ifdef __cplusplus
extern "C" {
#endif

int __io_putchar(int ch);

#ifdef __cplusplus
}
#endif

#endif /* INC_IO_H_ */
